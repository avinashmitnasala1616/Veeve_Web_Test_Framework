# Veeva Technical Assessment – Web Test Automation (Multi-Module)

**Author:** Avinash Mitnasala  
**Tech:** Java 17, Selenium 4, Cucumber + TestNG, Maven, WebDriverManager, Extent Reports, Log4j2

## Modules
- `automation-framework` – reusable core (driver, waits, config, CSV, hooks)
- `core-product-tests` – Warriors (CP) tests
- `derived-product1-tests` – 76ers (DP1) tests
- `derived-product2-tests` – Bulls (DP2) tests

## Prereqs
- JDK 17+, Maven 3.9+
- Chrome/Firefox installed (drivers auto-managed)

## Run All
```bash
mvn -q -DskipTests=false -Dcucumber.tags=@smoke test
# or via TestNG suite
mvn -q -Dtestng.dtd.http=true -Dsurefire.suiteXmlFiles=testng.xml test
```

## Run Single Module
```bash
cd core-product-tests && mvn test
```

## Reports & Artifacts
- Cucumber HTML reports per module under `reports/`
- CSV/Text outputs under `reports/`
- Logs under `logs/`

## Notes
- Locators are resilient (CSS/XPath fallbacks) to cope with frequent NBA site changes.
- Framework is **parallel-ready** with ThreadLocal drivers via `DriverFactory`.
- Data/config externalized in `automation-framework/src/test/resources/config.properties`.
