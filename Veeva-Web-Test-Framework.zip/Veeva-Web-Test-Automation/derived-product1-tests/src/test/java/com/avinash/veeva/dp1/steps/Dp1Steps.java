package com.avinash.veeva.dp1.steps;

import java.time.Duration;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.avinash.veeva.dp1.pages.SixersHomePage;
import com.avinash.veeva.framework.CSVUtils;
import com.avinash.veeva.framework.ConfigManager;
import com.avinash.veeva.framework.DriverFactory;
import com.avinash.veeva.framework.ExtentManager;
import com.avinash.veeva.framework.WaitUtils;

import io.cucumber.java.en.*;

public class Dp1Steps {

    private WebDriver driver;
    private WaitUtils wait;
    private SixersHomePage home;

    private static final By BANNER_LINK = By.cssSelector("a.TileHero_tileLink__VTMPI[aria-label]");

    @Given("I open the DP1 home page")
    public void i_open_the_dp1_home_page() {
        driver = DriverFactory.getDriver();
        if (driver == null) {
            String browser = System.getProperty("browser",
                    ConfigManager.get("browser", "chrome"));
            DriverFactory.initDriver(browser);
            driver = DriverFactory.getDriver();
            driver.manage().window().maximize();
        }

        int timeout = ConfigManager.getInt("wait.timeout.sec", 15);
        wait = new WaitUtils(driver, timeout);

        String url = ConfigManager.get("dp1.url", "https://www.nba.com/sixers/");
        driver.get(url);

        home = new SixersHomePage(driver, wait);
        home.waitUntilHeroReady(); 

        ExtentManager.logInfo("Opened DP1 home: " + url);
    }

    @Then("Below Tickets menu I should see {int} slides")
    public void below_tickets_menu_i_should_see_slides(Integer expectedCount) {
        int actual = home.getSlideCount();
        if (expectedCount <= 0) {
            Map<String, String> row = CSVUtils.readFirstRow("testdata/expected_count.csv");
            expectedCount = Integer.parseInt(row.getOrDefault("expected_count", "0"));
        }
        ExtentManager.logInfo("Slide count found: " + actual + ", expected: " + expectedCount);
        Assert.assertEquals(actual, expectedCount.intValue(), "Slide count mismatch.");
    }

    @Then("The slide titles should match my expected data")
    public void the_slide_titles_should_match_expected() {
        List<String> actual = home.getSlideTitles();
        ExtentManager.logInfo("Actual titles: " + actual);

        List<Map<String, String>> rows = CSVUtils.readAll("testdata/expected_titles.csv");
        List<String> expected = rows.stream()
                .map(r -> r.get("title"))
                .filter(Objects::nonNull)
                .map(String::trim)
                .collect(Collectors.toList());

        ExtentManager.logInfo("Expected titles: " + expected);
        Assert.assertEquals(new HashSet<>(actual), new HashSet<>(expected), "Slide titles mismatch.");
    }

    @Then("Each slide should play for the expected duration")
    public void each_slide_should_play_for_the_expected_duration() {
        List<Map<String, String>> rows = CSVUtils.readAll("testdata/expected_durations.csv");
        LinkedHashMap<String, Long> expectedMs  = new LinkedHashMap<>();
        LinkedHashMap<String, Long> toleranceMs = new LinkedHashMap<>();
        for (Map<String, String> r : rows) {
            String t = r.get("title");
            if (t == null) continue;
            expectedMs.put(t.trim(), Long.parseLong(r.getOrDefault("duration_ms", "0")));
            toleranceMs.put(t.trim(), Long.parseLong(r.getOrDefault("tolerance_ms", "2500")));
        }

        measureOneInterval();

        Map<String, Long> measured = new LinkedHashMap<>();

        for (String title : expectedMs.keySet()) {
            waitUntilHeroLabelIs(title, 40);
            long ms = measureOneInterval();
            measured.put(title, ms);
        }

        ExtentManager.logInfo("Measured durations (ms): " + measured);

        for (Map.Entry<String, Long> e : expectedMs.entrySet()) {
            String title = e.getKey();
            long expected = e.getValue();
            long tol = toleranceMs.getOrDefault(title, 2500L);
            long got = measured.getOrDefault(title, 0L);
            long diff = Math.abs(got - expected);

            ExtentManager.logInfo(
                String.format("Title: %s | expected %d±%d ms, measured %d ms (diff %d ms)",
                    title, expected, tol, got, diff)
            );
            Assert.assertTrue(
                diff <= tol,
                String.format("Duration for '%s' out of range. expected %d±%d, got %d (diff %d)",
                    title, expected, tol, got, diff)
            );
        }
    }


    private String currentTitle() {
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement visible = w.until(d -> {
            List<WebElement> links = d.findElements(BANNER_LINK);
            for (WebElement a : links) {
                try {
                    if (a.isDisplayed() && a.getRect().getWidth() > 0 && a.getRect().getHeight() > 0) {
                        return a;
                    }
                } catch (StaleElementReferenceException ignored) {}
            }
            return null;
        });
        return visible.getAttribute("aria-label").trim();
    }

    private void waitUntilHeroLabelIs(String wanted, int maxWaitSec) {
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(maxWaitSec));
        w.until(d -> {
            try {
                return wanted.equals(currentTitle());
            } catch (NoSuchElementException | StaleElementReferenceException ignored) {
                return false;
            }
        });
    }

    private long measureOneInterval() {
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(35));
        String before = currentTitle();
        long start = System.currentTimeMillis();

        w.until(d -> {
            try {
                String now = currentTitle();
                return !now.equals(before);
            } catch (NoSuchElementException | StaleElementReferenceException ignored) {
                return false;
            }
        });

        return System.currentTimeMillis() - start;
    }
}