package com.avinash.veeva.dp1.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.avinash.veeva.framework.WaitUtils;

import java.time.Duration;
import java.util.*;
import java.util.function.Supplier;

public class SixersHomePage {
    private final WebDriver driver;
    private final WaitUtils wait;
    private final int timeoutSec;

    // Stable locators: do NOT depend on hashed class suffixes
    private static final By SLIDE_LINKS =
            By.cssSelector("section[class*='TileHero'] a[aria-label], div[class*='TileHero'] a[aria-label]");

    @FindBy(css = "section[class*='TileHero'], div[class*='TileHero'], main")
    private WebElement heroContainer;

    public SixersHomePage(WebDriver driver, WaitUtils wait) {
        this.driver = driver;
        this.wait = wait;
        // If WaitUtils exposes getter, use it; otherwise set from config or constant
        this.timeoutSec =  Math.max(8, 15); // fallback if you don't have wait.getTimeoutSec()
        PageFactory.initElements(driver, this);
    }

    /** Make sure hero is on screen and at least one slide anchor is present. */
    public void waitUntilHeroReady() {
        try {
            if (heroContainer != null) {
                wait.waitForVisible(heroContainer);
                // scroll into view to trigger lazy hydration
                ((JavascriptExecutor) driver).executeScript(
                        "arguments[0].scrollIntoView({behavior:'instant',block:'center'})", heroContainer);
            }
        } catch (Throwable ignored) {}

        // wait for at least 1 slide anchor to be present
        new WebDriverWait(driver, Duration.ofSeconds(timeoutSec))
                .until(ExpectedConditions.numberOfElementsToBeMoreThan(SLIDE_LINKS, 0));

        // small settle to allow text/aria to attach
        sleep(250);
    }

    /** Virtualized carousel ⇒ enumerate titles over time (autoplay) and count unique ones. */
    public int getSlideCount() {
        LinkedHashSet<String> titles = enumerateUniqueTitles( /*maxTransitions*/ 20, /*maxSeconds*/ 40);
        return titles.size();
    }

    /** Virtualized carousel ⇒ collect all unique titles in the order they first appear. */
    public List<String> getSlideTitles() {
        LinkedHashSet<String> titles = enumerateUniqueTitles( /*maxTransitions*/ 20, /*maxSeconds*/ 40);
        return new ArrayList<>(titles);
    }

    /**
     * Measure how long each slide title remains visible while autoplay runs.
     * @param cyclesToObserve max number of title changes to record (use slideCount + padding)
     * @param maxSeconds hard timeout to stop timing loop
     */
    public Map<String, Long> measureSlideDurations(int cyclesToObserve, int maxSeconds) {
        Map<String, Long> durations = new LinkedHashMap<>();
        long endBy = System.currentTimeMillis() + (maxSeconds * 1000L);

        Supplier<String> currentTitle = this::getCurrentVisibleTitle;

        // prime
        String prev = currentTitle.get();
        long prevStart = System.currentTimeMillis();
        // require a valid start
        if (prev == null) {
            // wait a bit for first title
            prev = waitForTitleChange(null, /*maxWaitMs*/ timeoutSec * 1000L);
            prevStart = System.currentTimeMillis();
        }

        int changes = 0;
        while (System.currentTimeMillis() < endBy && changes < Math.max(1, cyclesToObserve)) {
            String changed = waitForTitleChange(prev, 12000); // up to 12s per change
            if (changed == null) break; // autoplay stalled or timeouts

            // close out previous
            long dur = System.currentTimeMillis() - prevStart;
            if (dur > 50) durations.merge(prev, dur, Long::sum);

            // move to next
            prev = changed;
            prevStart = System.currentTimeMillis();
            changes++;
        }

        // close last visible
        if (prev != null) {
            long dur = System.currentTimeMillis() - prevStart;
            if (dur > 50) durations.merge(prev, dur, Long::sum);
        }
        return durations;
    }

    /* ------------------------- helpers ------------------------- */

    /** Polls visible slides and returns the aria-label of the currently visible one. */
    private String getCurrentVisibleTitle() {
        List<WebElement> anchors = driver.findElements(SLIDE_LINKS);
        for (WebElement el : anchors) {
            try {
                if (el.isDisplayed() && el.getRect().getWidth() > 4 && el.getRect().getHeight() > 4) {
                    String t = el.getAttribute("aria-label");
                    if (t != null && !t.isBlank()) return t.trim();
                }
            } catch (StaleElementReferenceException ignored) {}
        }
        return null;
    }

    /**
     * Wait until the visible slide title changes away from prevTitle (or becomes any non-null if prevTitle is null).
     * Returns the new title, or null on timeout.
     */
    private String waitForTitleChange(String prevTitle, long maxWaitMs) {
        long end = System.currentTimeMillis() + Math.max(500L, maxWaitMs);
        String last = null;
        while (System.currentTimeMillis() < end) {
            String now = getCurrentVisibleTitle();
            if (prevTitle == null) {
                if (now != null && stableFor(150)) return now; // first non-null
            } else if (now != null && !now.equals(prevTitle) && stableFor(150)) {
                return now;
            }
            last = now;
            sleep(120);
        }
        return null;
    }

    /** Basic debouncer to reduce flicker noise: returns true if current title stayed unchanged for ~150ms. */
    private boolean stableFor(long ms) {
        String first = getCurrentVisibleTitle();
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (!Objects.equals(first, getCurrentVisibleTitle())) return false;
            sleep(50);
        }
        return true;
    }

    /** Enumerate unique titles until we loop or time out. */
    private LinkedHashSet<String> enumerateUniqueTitles(int maxTransitions, int maxSeconds) {
        long endBy = System.currentTimeMillis() + (maxSeconds * 1000L);
        LinkedHashSet<String> seen = new LinkedHashSet<>();

        String first = getCurrentVisibleTitle();
        if (first == null) first = waitForTitleChange(null, timeoutSec * 1000L);
        if (first != null) seen.add(first);

        String prev = first;
        int changes = 0;

        while (System.currentTimeMillis() < endBy && changes < Math.max(1, maxTransitions)) {
            String next = waitForTitleChange(prev, 12000);
            if (next == null) break;
            if (seen.contains(next) && next.equals(first)) {
                // looped back to start ⇒ likely full set collected
                seen.add(next); // no-op, preserves order
                break;
            }
            seen.add(next);
            prev = next;
            changes++;
        }
        return seen;
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}