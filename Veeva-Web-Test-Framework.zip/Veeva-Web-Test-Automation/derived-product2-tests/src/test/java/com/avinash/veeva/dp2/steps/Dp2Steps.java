package com.avinash.veeva.dp2.steps;

import com.avinash.veeva.dp2.pages.BullsHomePage;
import com.avinash.veeva.framework.DriverFactory;

import io.cucumber.java.en.*;
import static org.testng.Assert.assertTrue;

import java.util.Map;

import org.openqa.selenium.WebDriver;

public class Dp2Steps {

    private WebDriver driver;
    private BullsHomePage home;
    private Map<String, Long> duplicates;

    @Given("I open Bulls home page")
    public void openHome() {
    	driver = DriverFactory.getDriver();
        if (driver == null) {
            driver = DriverFactory.initDriver();
            driver.manage().window().maximize();
        }
        home = new BullsHomePage();
        home.open();
    }

    @When("I collect all footer hyperlinks")
    public void collectFooter() {
        home.scrollToFooter();
    }

    @Then("I export them to CSV and highlight duplicates")
    public void exportAndHighlight() {
        duplicates = home.exportLinksAndFindDuplicates("reports/dp2_footer_links.csv");
        home.writeDuplicatesTxt("dp2_footer_duplicates.txt", duplicates);

        assertTrue(duplicates != null); 
    }
}