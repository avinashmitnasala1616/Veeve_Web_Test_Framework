package com.avinash.veeva.dp2.pages;

import com.avinash.veeva.framework.DriverFactory;
import com.avinash.veeva.framework.WaitUtils;
import com.avinash.veeva.framework.CSVUtils;
import org.openqa.selenium.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

public class BullsHomePage {

    private final WebDriver d;
    private final WaitUtils wait;

    private final By footer = By.tagName("footer");
    private final By linksInFooter = By.cssSelector("a[href]");

    public BullsHomePage() {
        this.d = DriverFactory.getDriver();
        this.wait = new WaitUtils(d, 20);
    }

    public void open() {
        d.get("https://www.nba.com/bulls");
    }

    public void scrollToFooter() {
        WebElement f = wait.visible(footer);
        ((JavascriptExecutor) d).executeScript("arguments[0].scrollIntoView({block:'end'});", f);
        ((JavascriptExecutor) d).executeScript("window.scrollBy(0, 200);");
        wait.visible(linksInFooter);
    }

    /** Returns all footer hrefs */
    public List<String> getFooterHrefs() {
        WebElement f = d.findElement(footer);
        List<WebElement> anchors = f.findElements(linksInFooter);

        return anchors.stream()
                .map(a -> a.getAttribute("href"))
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .collect(Collectors.toList());
    }

    /** Writes all URLs + counts to CSV and returns duplicates */
    public Map<String, Long> exportLinksAndFindDuplicates(String csvRelPath) {
        List<String> hrefs = getFooterHrefs();
        Map<String, Long> counts = hrefs.stream()
                .collect(Collectors.groupingBy(u -> u, LinkedHashMap::new, Collectors.counting()));

        List<List<String>> rows = counts.entrySet().stream()
                .map(e -> List.of(e.getKey(), String.valueOf(e.getValue())))
                .collect(Collectors.toList());
        CSVUtils.writeRows(csvRelPath, new String[]{"URL", "Count"}, rows);

        return counts.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                        (a,b)->a, LinkedHashMap::new));
    }

    /** Writes a human-readable duplicates report. */
    public void writeDuplicatesTxt(String relPath, Map<String, Long> dups) {
        try {
            Path out = Path.of("reports").resolve(relPath);
            Files.createDirectories(out.getParent());
            List<String> lines = new ArrayList<>();
            if (dups.isEmpty()) {
                lines.add("No duplicates found.");
            } else {
                lines.add("Duplicate URLs (URL | Count):");
                dups.forEach((u,c) -> lines.add(u + " | " + c));
            }
            Files.write(out, lines);
        } catch (Exception e) {
            throw new RuntimeException("Failed writing duplicates txt", e);
        }
    }
}