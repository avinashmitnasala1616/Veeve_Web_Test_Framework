package com.avinash.veeva.cp.pages;

import com.avinash.veeva.framework.ConfigManager;
import com.avinash.veeva.framework.PopUpUtils;
import com.avinash.veeva.framework.WaitUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Set;

public class WarriorsShopNavPage {

    private final WebDriver d;
    private final WaitUtils wait;

    public WarriorsShopNavPage(WebDriver driver, WaitUtils wait) {
        this.d = driver;
        this.wait = wait;
        PageFactory.initElements(d, this);
    }

    @FindBy(css =
            "nav[aria-label='header-secondary-menu'] " +
            "[data-testid^='nav-item-https://shop.warriors.com/'] > a"
        )
    private WebElement shopTop;
    
    private final By mensLinkBy = By.cssSelector(
            // via data-testid of the <li>
            "nav[id^='nav-dropdown-desktop'] [data-testid^='nav-item-https://shop.warriors.com/golden-state-warriors-men/'] a," +
            // or by the anchor’s title attr
            "nav[id^='nav-dropdown-desktop'] a[title=\"Men's\"]"
        );


    public void open(String url) {
        d.get(url);
        PopUpUtils.dismissInsiderIfPresent(d, 8);
    }

    /** Hover Shop and click “Men’s”, then switch to the newly opened tab. */
    public void goToMensFromShop() {
        WebDriverWait shortWait = new WebDriverWait(d, Duration.ofSeconds(Math.max(5,  wait.getTimeoutSec())));
        Actions actions = new Actions(d);

        // Some builds render only after a tiny scroll nudge
        try { ((JavascriptExecutor) d).executeScript("window.scrollTo(0, 0)"); } catch (Exception ignored) {}

        // Try a few times: hover SHOP → find Men's → click
        WebElement mensLink = null;
        for (int attempt = 1; attempt <= 4; attempt++) {
            try {
                wait.waitForVisible(shopTop);
                actions.moveToElement(shopTop).pause(Duration.ofMillis(250)).perform();
                // tiny mouse jitter to keep menu open
                actions.moveByOffset(2, 2).pause(Duration.ofMillis(120)).perform();

                mensLink = shortWait.until(ExpectedConditions.presenceOfElementLocated(mensLinkBy));
                ((JavascriptExecutor) d).executeScript("arguments[0].scrollIntoView({block:'center'})", mensLink);
                break;
            } catch (TimeoutException | NoSuchElementException e) {
                if (attempt == 4) throw new RuntimeException("Could not reveal Men's link from Shop after retries", e);
                sleep(200L * attempt);
            }
        }

        // Click and switch tab
        String original = d.getWindowHandle();
        Set<String> before = d.getWindowHandles();

        try {
            try {
                shortWait.until(ExpectedConditions.elementToBeClickable(mensLink));
                mensLink.click();
            } catch (Exception clickFallback) {
                ((JavascriptExecutor) d).executeScript("arguments[0].click()", mensLink);
            }
        } catch (Throwable t) {
            // Hard fallback: navigate directly if href is known on the element
            try {
                String href = mensLink.getAttribute("href");
                if (href != null && !href.isBlank()) {
                    ((JavascriptExecutor) d).executeScript("window.open(arguments[0],'_blank');", href);
                } else {
                    // last-ditch: go to configured URL if you add one in config
                    String direct = ConfigManager.get("cp.mens.url", "");
                    if (!direct.isBlank()) ((JavascriptExecutor) d).executeScript("window.open(arguments[0],'_blank');", direct);
                }
            } catch (Exception ignored) {}
        }

        // Wait for new tab and switch
        WebDriverWait tabWait = new WebDriverWait(d, Duration.ofSeconds(10));
        tabWait.until(driver -> driver.getWindowHandles().size() > before.size());

        for (String h : d.getWindowHandles()) {
            if (!before.contains(h)) {
                d.switchTo().window(h);
                break;
            }
        }

        // If somehow still on original, force switch to last handle
        if (d.getWindowHandle().equals(original) && d.getWindowHandles().size() > 1) {
            String last = d.getWindowHandles().stream().reduce((a, b) -> b).orElse(original);
            d.switchTo().window(last);
        }
    }
    
    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}