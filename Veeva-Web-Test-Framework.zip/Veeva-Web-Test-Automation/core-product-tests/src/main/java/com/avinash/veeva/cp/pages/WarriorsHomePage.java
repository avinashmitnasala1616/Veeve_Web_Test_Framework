package com.avinash.veeva.cp.pages;

import com.avinash.veeva.framework.ConfigManager;
import com.avinash.veeva.framework.PopUpUtils;
import com.avinash.veeva.framework.WaitUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WarriorsHomePage {
    private final WebDriver d;
    private final WaitUtils wait;

    public WarriorsHomePage(WebDriver driver, WaitUtils wait) {
        this.d = driver;
        this.wait = wait;
        PageFactory.initElements(d, this);
    }

    @FindBy(css = "nav[aria-label='header-secondary-menu'] [data-testid='nav-item-#'] > a")
    private WebElement overflowTrigger;
    
    private final By newsLinkBy = By.cssSelector(
            "nav[id^='nav-dropdown-desktop'] a[title='News & Features'], " +
            "[data-testid='nav-item-/warriors/news'] a[title='News & Features']"
    );


    public void open(String url) {
        d.get(url);
        PopUpUtils.dismissInsiderIfPresent(d, 8);
    }

    private WebElement revealNewsLinkWithHover() {
        WebDriverWait shortWait = new WebDriverWait(d, Duration.ofSeconds(Math.max(5, wait.getTimeoutSec())));
        Actions actions = new Actions(d);

        for (int attempt = 1; attempt <= 4; attempt++) {
            try {
                wait.waitForVisible(overflowTrigger);

                actions.moveToElement(overflowTrigger)
                       .pause(Duration.ofMillis(250))
                       .perform();
                actions.moveByOffset(2, 2).pause(Duration.ofMillis(120)).perform();

                WebElement link = shortWait.until(ExpectedConditions.presenceOfElementLocated(newsLinkBy));

                ((JavascriptExecutor) d).executeScript("arguments[0].scrollIntoView({block:'center'})", link);
                return link;
            } catch (TimeoutException | NoSuchElementException e) {
                if (attempt == 4) throw e;
                try { Thread.sleep(200L * attempt); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            }
        }
        throw new NoSuchElementException("News & Features link not present after retries");
    }

    public void goToNewsAndFeatures() {
        try {
            WebElement link = revealNewsLinkWithHover();
            ((JavascriptExecutor) d).executeScript("arguments[0].click()", link);
        } catch (Exception e) {
            String base = ConfigManager.get("cp.url", "https://www.nba.com/warriors/");
            if (!base.endsWith("/")) base += "/";
            d.navigate().to(base + "news");
        }
    }
}