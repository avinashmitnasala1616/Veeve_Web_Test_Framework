package com.avinash.veeva.cp.pages;

import com.avinash.veeva.framework.WaitUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WarriorsMensPage {

    private final WebDriver d;
    private final WaitUtils wait;

    public WarriorsMensPage(WebDriver driver, WaitUtils wait) {
        this.d = driver; this.wait = wait;
        PageFactory.initElements(driver, this);
    }

    // “Jackets” subcategory/filter (several variants just in case)
    @FindBy(css = "a[href*='jacket' i], a[title*='Jacket' i]")
    private List<WebElement> jacketsLinks;

    // A single product “card”
    // (from your HTML: ".columns small-12 medium-12" inside ".product-card row")
    @FindBy(css = "div.product-card.row div.columns.small-12.medium-12")
    private List<WebElement> productCards;

    // Pagination “Next”
    @FindBy(css = "a[rel='next'], a.pagination-next, a[aria-label='Next']")
    private List<WebElement> nextButtons;

    public static class Item {
        public final String title;
        public final String price;
        public final String topSeller; // "" if none
        public Item(String t, String p, String ts) {
            title=t; price=p; topSeller=ts;
        }
        @Override public String toString() {
            String badge = topSeller == null ? "" : topSeller;
            return String.format("%s | %s | %s", title, price, badge);
        }
    }

    /** If a “Jackets” filter/link exists, click it. */
    public void openJacketsIfPresent() {
        for (WebElement a : jacketsLinks) {
            try {
                String txt = a.getText() == null ? "" : a.getText().toLowerCase(Locale.ENGLISH);
                String href = a.getAttribute("href");
                if (txt.contains("jacket") || (href != null && href.toLowerCase(Locale.ENGLISH).contains("jacket"))) {
                    a.click();
                    // small wait for content load
                    wait.sleep(800);
                    break;
                }
            } catch (StaleElementReferenceException ignored) {}
        }
    }

    /** Scrape all jackets across pagination. */
    public List<Item> collectAllJackets() {
        List<Item> out = new ArrayList<>();
        int pageGuard = 60; // safety to avoid infinite loops

        do {
            wait.waitForAnyVisible(productCards);

            for (WebElement card : productCards) {
                try {
                    String title = text(card, "div.product-card-title a, .product-card-title a");
                    if (title.isBlank()) continue;

                    // Only take jackets (if we are not already in the jackets listing)
                    String low = title.toLowerCase(Locale.ENGLISH);
                    if (!low.contains("jacket")) continue;

                    String price = text(card, "div.price-card, [data-talos='srpProductPrice']");
                    String badge = ""; // look for “Top Seller” anywhere inside card
                    String whole = card.getText().toLowerCase(Locale.ENGLISH);
                    if (whole.contains("top seller")) badge = "Top Seller";

                    out.add(new Item(title, price, badge));
                } catch (StaleElementReferenceException ignored) {}
            }

        } while (goNextIfPossible(--pageGuard));

        return out;
    }

    private boolean goNextIfPossible(int guard) {
        if (guard <= 0) return false;
        try {
            for (WebElement n : nextButtons) {
                if (n.isDisplayed() && n.isEnabled()) {
                    String oldUrl = d.getCurrentUrl();
                    n.click();
                    // crude wait for URL/content change
                    for (int i = 0; i < 40; i++) {
                        if (!d.getCurrentUrl().equals(oldUrl)) break;
                        wait.sleep(200);
                    }
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static String text(WebElement root, String css) {
        try { return root.findElement(By.cssSelector(css)).getText().trim(); }
        catch (NoSuchElementException e) { return ""; }
    }
}