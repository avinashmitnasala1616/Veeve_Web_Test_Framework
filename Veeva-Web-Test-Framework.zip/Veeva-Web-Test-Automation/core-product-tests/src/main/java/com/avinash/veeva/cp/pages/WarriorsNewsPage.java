package com.avinash.veeva.cp.pages;

import com.avinash.veeva.framework.DateUtils;
import com.avinash.veeva.framework.DomUtils;
import com.avinash.veeva.framework.WaitUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

public class WarriorsNewsPage {

    private final WebDriver d;
    private final WaitUtils wait;

    public WarriorsNewsPage(WebDriver driver, WaitUtils wait) {
        this.d = driver;
        this.wait = wait;
        PageFactory.initElements(driver, this);
    }

    @FindBy(css = "[data-testid='tile-article']")
    private List<WebElement> tiles;

    public static class Tile {
        public final String title;
        public final String publishedRaw; // e.g., "1 day ago" or "Sat Oct 18 2025"
        public final String href;
        public final long ageDays;
        public Tile(String t, String p, String h, long a) {
            title = t; publishedRaw = p; href = h; ageDays = a;
        }
        @Override public String toString() {
            return String.format("%s | %s | age=%d | %s", title, publishedRaw, ageDays, href);
        }
    }

    public List<Tile> collectTiles() {
        wait.waitForAnyVisible(tiles);

        List<Tile> out = new ArrayList<>();
        for (WebElement tile : tiles) {
            try {
                String title = DomUtils.extractTileTitle(tile);

                String published = DomUtils.attr(tile, "[data-testid='tile-meta'] time", "aria-label");
                if (published.isBlank()) {
                    published = DomUtils.textOrAttr(tile, "[data-testid='tile-meta'] time", "datetime");
                }

                String href = DomUtils.attr(tile, "[data-testid='tile-article-link']", "href");
                long age = DateUtils.toAgeDays(published, java.time.ZoneId.systemDefault());

                out.add(new Tile(title, published, href, age));
            } catch (org.openqa.selenium.StaleElementReferenceException ignored) { }
        }
        return out;
    }
}