package com.avinash.veeva.cp.steps;

import com.avinash.veeva.cp.pages.WarriorsHomePage;
import com.avinash.veeva.cp.pages.WarriorsNewsPage;
import com.avinash.veeva.framework.CSVUtils;
import com.avinash.veeva.framework.ConfigManager;
import com.avinash.veeva.framework.DriverFactory;
import com.avinash.veeva.framework.ExtentManager;
import com.avinash.veeva.framework.WaitUtils;
import io.cucumber.java.en.*;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.*;
import java.util.stream.Collectors;

public class CpSteps {

    private WebDriver driver;
    private WaitUtils wait;
    private WarriorsHomePage home;
    private WarriorsNewsPage newFeatures;
    private List<WarriorsNewsPage.Tile> collected = List.of();

    @Given("I am on the CP home page")
    public void openHome() {
        driver = DriverFactory.getDriver();
        if (driver == null) {
            driver = DriverFactory.initDriver(); 
            driver.manage().window().maximize();
        }

        wait  = new WaitUtils(driver, ConfigManager.getInt("wait.timeout.sec", 15));
        home  = new WarriorsHomePage(driver, wait);

        home.open(ConfigManager.get("cp.url", "https://www.nba.com/warriors/"));
        ExtentManager.logInfo("Opened CP home");
    }

    @When("I click \"News & Features\"")
    public void clickNewsAndFeatures() {
        home.goToNewsAndFeatures();
        newFeatures = new WarriorsNewsPage(driver, wait);
    }

    @When("I collect all video\\/article tiles with their published timestamps")
    public void collectAllTilesWithTimestamps() {
        collected = newFeatures.collectTiles();

        String preview = collected.stream()
                .limit(8)
                .map(t -> String.format("%s | %s | age=%dd",
                        t.title, t.publishedRaw, t.ageDays))
                .collect(Collectors.joining("\n"));
        ExtentManager.logInfo("Collected " + collected.size() + " tiles\n" + preview);
    }

    @Then("the number of items published at least 3 days ago should be >= 3")
    public void assertDefaultMinCount() {
        int days = Integer.parseInt(ConfigManager.get("cp.video.age.days", "3"));
        int min  = Integer.parseInt(ConfigManager.get("cp.video.min.count", "3"));

        List<WarriorsNewsPage.Tile> aged = collected.stream()
                .filter(t -> t.ageDays >= days)
                .collect(Collectors.toList());

        ExtentManager.logInfo(String.format("Total=%d | >=%dd = %d",
                collected.size(), days, aged.size()));
        Assert.assertTrue(aged.size() >= min,
                String.format("Expected at least %d items aged >= %d days, but found %d",
                        min, days, aged.size()));
        String csvPath = ConfigManager.get("cp.report.path", "reports/cp_news_aged_items.csv");
        String[] header = {"title", "published_raw", "age_days", "url"};

        List<List<String>> rows = aged.stream()
                .map(t -> List.of(
                        t.title,
                        t.publishedRaw,
                        String.valueOf(t.ageDays),
                        t.href == null ? "" : t.href))
                .collect(Collectors.toList());

        CSVUtils.writeRows(csvPath, header, rows);
        ExtentManager.logInfo("Wrote aged items report to: " + csvPath);
        
    }
}