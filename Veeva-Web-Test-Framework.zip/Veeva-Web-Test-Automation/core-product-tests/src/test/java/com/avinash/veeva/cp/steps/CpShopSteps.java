package com.avinash.veeva.cp.steps;

import com.avinash.veeva.cp.pages.WarriorsMensPage;
import com.avinash.veeva.cp.pages.WarriorsShopNavPage;
import com.avinash.veeva.framework.*;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Collectors;

public class CpShopSteps {

    private WebDriver driver;
    private WaitUtils wait;
    private Scenario scenario;
    private WarriorsShopNavPage shopNav;
    private WarriorsMensPage mens;

    @Before
    public void inject(Scenario s) {
        this.scenario = s;
    }

    @Given("I open CP home and go to Shop > Men's")
    public void openHomeAndGoToMens() {
        driver = DriverFactory.getDriver();
        if (driver == null) {
            driver = DriverFactory.initDriver();
            driver.manage().window().maximize();
        }

        wait = new WaitUtils(driver, ConfigManager.getInt("wait.timeout.sec", 15));
        shopNav = new WarriorsShopNavPage(driver, wait);

        // open home + navigate
        shopNav.open(ConfigManager.get("cp.url", "https://www.nba.com/warriors/"));
        shopNav.goToMensFromShop();  // switches tab
        mens = new WarriorsMensPage(driver, wait);

        ExtentManager.logInfo("Navigated to Men's Shop page");
    }

    @When("I export all Men's Jackets (with pagination) to a text file")
    public void exportAllMensJackets() throws Exception {
        // Click “Jackets” filter (if available)
        mens.openJacketsIfPresent();

        // Collect jackets across all pages
        List<WarriorsMensPage.Item> jackets = mens.collectAllJackets();

        // Prepare text lines
        List<String> lines = jackets.stream()
                .map(WarriorsMensPage.Item::toString)
                .collect(Collectors.toList());

        // Default output path (from config or fallback)
        String outPath = ConfigManager.get("cp.mens.jackets.report",
                "reports/cp_mens_jackets.txt");
        Path p = Path.of(outPath);

        // Write file directly here (no helper class)
        Files.createDirectories(p.getParent());
        Files.write(p, lines);

        ExtentManager.logInfo("Wrote Men's Jackets report to: " + p.toAbsolutePath());

        // Attach text file to Cucumber HTML report
        try {
            scenario.attach(Files.readAllBytes(p), "text/plain", "cp_mens_jackets.txt");
        } catch (Throwable ignored) {}
    }

    @Then("the operation should succeed")
    public void verifyFileGenerated() {
        String path = ConfigManager.get("cp.mens.jackets.report", "reports/cp_mens_jackets.txt");
        Path p = Path.of(path);
        Assert.assertTrue(Files.exists(p), "Expected jackets report file to exist");
        ExtentManager.logInfo("Verified report file exists: " + p.toAbsolutePath());
    }
}