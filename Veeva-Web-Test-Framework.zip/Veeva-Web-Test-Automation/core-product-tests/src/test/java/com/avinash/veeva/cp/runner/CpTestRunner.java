package com.avinash.veeva.cp.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
    features = "src/test/resources/features",
    glue = {"com.avinash.veeva.cp.steps", "com.avinash.veeva.framework"},
    plugin = {"pretty"},
    monochrome = true,
    tags = "@cp_mens"
)
public class CpTestRunner extends AbstractTestNGCucumberTests {
}
