package com.avinash.veeva.framework;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Hooks {

    private WebDriver driver;

    @Before
    public void setUp(Scenario scenario) {
        String browser = System.getProperty("browser",
                ConfigManager.get("browser", "chrome"));

        driver = DriverFactory.initDriver(browser);
        driver.manage().window().maximize();

        try {
            new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.elementToBeClickable(
                    By.id("onetrust-accept-btn-handler")))
                .click();
        } catch (Exception ignored) {}

        try {
            ExtentManager.startTest(scenario.getName());
        } catch (Throwable ignored) {}
    }

    @After
    public void tearDown(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                try {
                    WebDriver d = DriverFactory.getDriver();
                    if (d == null) d = driver;

                    if (d instanceof TakesScreenshot) {
                        TakesScreenshot ts = (TakesScreenshot) d;
                        byte[] ss = ts.getScreenshotAs(OutputType.BYTES);
                        scenario.attach(ss, "image/png", "failure");
                    }
                } catch (Throwable ignoreScreenshot) {
                }
            }
        } finally {
            try {
                ExtentManager.endTest();
            } catch (Throwable ignored) {}
            DriverFactory.quitDriver();
        }
    }
}