package com.avinash.veeva.framework;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public final class ScrollUtils {
    private ScrollUtils() {}

    /**
     * Scrolls the target into view then waits for another locator to be visible.
     */
    public static void scrollIntoViewAndWait(By targetToScroll, By thenWaitFor, long waitSec) {
        var driver = DriverFactory.getDriver();
        var wait = new WaitUtils(driver, waitSec);
        WebElement el = wait.visible(targetToScroll);

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", el);
        ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, Math.max(50, window.innerHeight*0.33));");

        wait.visible(thenWaitFor);
    }
}