package com.avinash.veeva.framework;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class WaitUtils {
    private final WebDriver driver;
    private final WebDriverWait wait;
    private final int timeoutSeconds;

    public WaitUtils(WebDriver driver, long timeoutSeconds) {
        this.driver = driver;
        this.timeoutSeconds = (int) timeoutSeconds;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
    }

    public WebElement visible(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }

    public List<WebElement> visibleAll(By by) {
        return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
    }
    
    public void click(By by) {
        visible(by).click();
    }
    
    public void waitForVisible(WebElement element) {
        try {
            wait.until(ExpectedConditions.visibilityOf(element));
        } catch (TimeoutException e) {
            throw new RuntimeException("Element not visible after timeout: " + element, e);
        }
    }

    public void waitForAnyVisible(List<WebElement> elements) {
        wait.until(driver -> {
            if (elements == null || elements.isEmpty()) return false;
            for (WebElement e : elements) {
                try {
                    if (e.isDisplayed() &&
                        e.getRect().getWidth() > 0 &&
                        e.getRect().getHeight() > 0) {
                        return true;
                    }
                } catch (StaleElementReferenceException ignored) {}
            }
            return false;
        });
    }

    public void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
    
    public int getTimeoutSec() { 
        return timeoutSeconds;
    }
}
