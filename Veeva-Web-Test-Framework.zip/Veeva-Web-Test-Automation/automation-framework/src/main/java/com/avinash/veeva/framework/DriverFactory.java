package com.avinash.veeva.framework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
// add others if you support them: EdgeDriver, SafariDriver, etc.

public class DriverFactory {

    private static final ThreadLocal<WebDriver> TL = new ThreadLocal<>();

    public static WebDriver getDriver() {
        return TL.get();
    }
    
    public static WebDriver initDriver() {
        String browser = System.getProperty("browser",
                ConfigManager.get("browser", "chrome"));
        return initDriver(browser);
    }


    public static WebDriver initDriver(String browserName) {
        WebDriver existing = TL.get();
        if (existing != null) return existing;

        String browser = System.getProperty("browser",
                ConfigManager.get("browser", "chrome")).trim().toLowerCase();

        WebDriver driver;
        switch (browser) {
            case "firefox" -> driver = new FirefoxDriver();
            case "chrome" -> driver = new ChromeDriver();
            default -> throw new IllegalArgumentException("Unsupported browser: " + browser);
        }

        TL.set(driver);
        return driver;
    }

    public static void quitDriver() {
        try {
            WebDriver d = TL.get();
            if (d != null) d.quit();
        } finally {
            TL.remove();
        }
    }
}