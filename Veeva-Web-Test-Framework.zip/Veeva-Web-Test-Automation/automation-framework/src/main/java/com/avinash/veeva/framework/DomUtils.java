package com.avinash.veeva.framework;

import org.openqa.selenium.*;

import java.util.List;

public final class DomUtils {
    private DomUtils() {}

    public static String text(WebElement root, String css) {
        try { return root.findElement(By.cssSelector(css)).getText().trim(); }
        catch (NoSuchElementException e) { return ""; }
    }

    public static String attr(WebElement root, String css, String name) {
        try { return root.findElement(By.cssSelector(css)).getAttribute(name); }
        catch (NoSuchElementException e) { return ""; }
    }

    public static String textOrAttr(WebElement root, String css, String attr) {
        String t = text(root, css);
        return !t.isBlank() ? t : attr(root, css, attr);
    }

    /** Try a list of selectors until one yields a non-blank text. */
    public static String firstNonBlankText(WebElement root, List<String> selectors) {
        for (String sel : selectors) {
            String t = text(root, sel);
            if (!t.isBlank()) return t;
        }
        return "";
    }

    /** Generic “tile” title extraction with common fallbacks. */
    public static String extractTileTitle(WebElement tile) {
        List<String> candidates = List.of(
            ".tile-article-title",
            "[data-testid='tile-article-title']",
            "h3, h2, h4"
        );
        String title = firstNonBlankText(tile, candidates);
        if (!title.isBlank()) return title;

        String fromAria = attr(tile, "[data-testid='tile-article-link']", "aria-label");
        if (!fromAria.isBlank()) return fromAria.trim();

        String fromTitleAttr = attr(tile, "a", "title");
        return fromTitleAttr == null ? "" : fromTitleAttr.trim();
    }
}