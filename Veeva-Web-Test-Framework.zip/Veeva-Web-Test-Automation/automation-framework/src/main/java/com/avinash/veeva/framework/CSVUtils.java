package com.avinash.veeva.framework;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class CSVUtils {
    public static void writeRows(String path, String[] header, List<List<String>> rows) {
        try {
            Files.createDirectories(Paths.get(path).getParent());
            try (CSVPrinter printer = new CSVPrinter(new FileWriter(path),
                    CSVFormat.DEFAULT.builder().setHeader(header).build())) {
                for (List<String> row : rows) {
                    printer.printRecord(row);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static List<Map<String, String>> readAll(String filePath) {
        List<Map<String, String>> recordsList = new ArrayList<>();

        try (InputStream is = CSVUtils.class.getClassLoader().getResourceAsStream(filePath)) {
            if (is == null) {
                throw new FileNotFoundException("CSV not found in classpath: " + filePath);
            }
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
                String[] headers = br.readLine().split(",");
                String line;
                while ((line = br.readLine()) != null) {
                    String[] values = line.split(",");
                    Map<String, String> row = new LinkedHashMap<>();
                    for (int i = 0; i < headers.length && i < values.length; i++) {
                        row.put(headers[i].trim(), values[i].trim());
                    }
                    recordsList.add(row);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read CSV file: " + filePath, e);
        }
        return recordsList;
    }
    
    public static Map<String, String> readFirstRow(String path) {
        try (Reader r = open(path);
             CSVParser p = new CSVParser(r, CSVFormat.DEFAULT.builder()
                     .setHeader()
                     .setSkipHeaderRecord(true)
                     .build())) {
            Iterator<CSVRecord> it = p.iterator();
            if (!it.hasNext()) return Collections.emptyMap();
            CSVRecord rec = it.next();
            Map<String, String> row = new LinkedHashMap<>();
            for (String h : p.getHeaderNames()) row.put(h, rec.get(h));
            return row;
        } catch (IOException e) {
            throw new RuntimeException("Failed to read first row from CSV: " + path, e);
        }
    }
    
    private static Reader open(String path) throws IOException {
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        InputStream is = cl.getResourceAsStream(path);
        if (is != null) return new InputStreamReader(is);
        return new FileReader(path);
    }
}
