package com.avinash.veeva.framework;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public final class PopUpUtils {

    private PopUpUtils() {}

    /** Dismiss “Warriors Insider” (or any CustomModal) robustly. */
    public static void dismissInsiderIfPresent(WebDriver d, int timeoutSec) {
        WebDriverWait wait = new WebDriverWait(d, Duration.ofSeconds(timeoutSec));

        By dialogAny   = By.cssSelector("div[role='dialog'][aria-modal='true']");
        By modalClass  = By.cssSelector("div[role='dialog'][class*='InsiderPopup_modal']");
        By backdrop    = By.cssSelector("div[class*='CustomModal_backdrop']");
        By closeBtn    = By.cssSelector(
                "div[role='dialog'] [aria-label='Close'], " +
                "div[role='dialog'] button[aria-label*='close' i], " +
                "div[role='dialog'] button:has(svg), " +
                "div[role='dialog'] .flex-end button"
        );

        boolean present = isPresent(d, modalClass) || isPresent(d, dialogAny) || isPresent(d, backdrop);
        if (!present) return;

        try {
            WebElement btn = d.findElement(closeBtn);
            if (btn.isDisplayed() && btn.isEnabled()) {
                btn.click();
                if (gone(wait, dialogAny, modalClass, backdrop)) return;
            }
        } catch (NoSuchElementException ignored) {
        } catch (ElementClickInterceptedException ignored) {
        } catch (ElementNotInteractableException ignored) {
        }

        try {
            new Actions(d).sendKeys(Keys.ESCAPE).perform();
            if (gone(wait, dialogAny, modalClass, backdrop)) return;
        } catch (Exception ignored) {}

        try {
            String js =
                "document.querySelectorAll(\"div[role='dialog'][aria-modal='true'], " +
                "div[role='dialog'][class*='InsiderPopup_modal'], " +
                "div[class*='CustomModal_backdrop']\").forEach(e=>e.remove());";
            ((JavascriptExecutor) d).executeScript(js);
            gone(wait, dialogAny, modalClass, backdrop);
        } catch (Exception ignored) {}
    }

    private static boolean isPresent(WebDriver d, By by) {
        try { return !d.findElements(by).isEmpty(); }
        catch (StaleElementReferenceException e) { return false; }
    }

    /** Wait until all of the given locators are absent or timeout. */
    private static boolean gone(WebDriverWait wait, By... locators) {
        try {
            return wait.until((ExpectedCondition<Boolean>) drv -> {
                for (By by : locators) {
                    if (!drv.findElements(by).isEmpty()) return false;
                }
                return true;
            });
        } catch (TimeoutException te) {
            return false;
        }
    }
}