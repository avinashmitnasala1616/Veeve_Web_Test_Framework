package com.avinash.veeva.framework;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DateUtils {
    private DateUtils() {}

    private static final Pattern DAYS_AGO  = Pattern.compile("(\\d+)\\s*day");
    private static final Pattern HOURS_AGO = Pattern.compile("(\\d+)\\s*hour");
    private static final Pattern MINS_AGO  = Pattern.compile("(\\d+)\\s*min");

    private static final List<DateTimeFormatter> ABSOLUTE_FORMATS = List.of(
        DateTimeFormatter.ofPattern("EEE MMM d yyyy", Locale.ENGLISH),
        DateTimeFormatter.ofPattern("MMM d, yyyy",   Locale.ENGLISH),
        DateTimeFormatter.ofPattern("yyyy-MM-dd")                     
    );

    /** Convert a raw date string (relative or absolute) to age in days. */
    public static long toAgeDays(String raw, ZoneId zone) {
        if (raw == null) return Long.MAX_VALUE;
        String s = raw.trim().toLowerCase(Locale.ENGLISH);
        if (s.isBlank()) return Long.MAX_VALUE;

        // Relative phrases
        if (s.contains("yesterday")) return 1;
        if (s.contains("today") || s.contains("just now")) return 0;

        Matcher m = DAYS_AGO.matcher(s);
        if (m.find()) return Long.parseLong(m.group(1));

        m = HOURS_AGO.matcher(s);
        if (m.find()) return Long.parseLong(m.group(1)) / 24;

        m = MINS_AGO.matcher(s);
        if (m.find()) return 0;

        // Absolute strings
        for (DateTimeFormatter f : ABSOLUTE_FORMATS) {
            try {
                LocalDate ld = LocalDate.parse(s, f);
                return daysBetween(ld, zone);
            } catch (RuntimeException ignore) {}
        }

        // “Oct 18” -> assume current year (or previous if future)
        try {
            LocalDate ld = LocalDate.parse(s + " " + Year.now().getValue(),
                DateTimeFormatter.ofPattern("MMM d yyyy", Locale.ENGLISH));
            long d = daysBetween(ld, zone);
            if (d < 0) d = daysBetween(ld.minusYears(1), zone);
            return d;
        } catch (RuntimeException ignore) {}

        return Long.MAX_VALUE; // unparseable → treat as very old (won’t break ≥ filters)
    }

    private static long daysBetween(LocalDate date, ZoneId zone) {
        return Duration.between(date.atStartOfDay(zone), ZonedDateTime.now(zone)).toDays();
    }
}