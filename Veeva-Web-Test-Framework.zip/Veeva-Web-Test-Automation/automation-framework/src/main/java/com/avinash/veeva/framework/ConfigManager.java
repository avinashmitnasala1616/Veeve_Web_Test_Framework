package com.avinash.veeva.framework;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigManager {

    private static final Properties props = new Properties();
    private static volatile boolean loaded = false;

    /** Load a .properties file (optional). Safe to call multiple times. */
    public static synchronized void load(String path) {
        try (FileInputStream fis = new FileInputStream(path)) {
            props.load(fis);
            loaded = true;
        } catch (IOException e) {
            // Keep running with defaults; do not throw.
            System.out.println("[ConfigManager] Could not load config file: " + path + " (using defaults).");
        }
    }

    /** Strict getter: throws if key is missing (use sparingly). */
    public static String get(String key) {
        String v = props.getProperty(key);
        if (v == null) throw new RuntimeException("Missing config key: " + key);
        return v;
    }

    /** Lenient getter with default fallback. */
    public static String get(String key, String def) {
        String v = props.getProperty(key);
        return (v == null || v.isBlank()) ? def : v.trim();
    }

    /** Lenient int getter with default fallback (never throws on missing/invalid). */
    public static int getInt(String key, int defaultValue) {
        String v = props.getProperty(key);
        if (v == null || v.isBlank()) return defaultValue;
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    /** Lenient boolean getter with default fallback. */
    public static boolean getBoolean(String key, boolean defaultValue) {
        String v = props.getProperty(key);
        if (v == null || v.isBlank()) return defaultValue;
        return Boolean.parseBoolean(v.trim());
    }

    /** Helper to check if any file was ever loaded (optional). */
    public static boolean isLoaded() {
        return loaded;
    }
}