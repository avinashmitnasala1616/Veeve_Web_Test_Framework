package com.avinash.veeva.framework;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

    private static ExtentReports extent;
    private static ExtentTest test;

    /**
     * Initialize or return the singleton ExtentReports instance.
     */
    public static ExtentReports getInstance() {
        if (extent == null) {
            ExtentSparkReporter spark = new ExtentSparkReporter("target/ExtentReport.html");
            spark.config().setDocumentTitle("Automation Execution Report");
            spark.config().setReportName("Veeva Web Automation");
            extent = new ExtentReports();
            extent.attachReporter(spark);
        }
        return extent;
    }

    /**
     * Start a new test entry in the report.
     */
    public static void startTest(String testName) {
        test = getInstance().createTest(testName);
        System.out.println("==== Starting Test: " + testName + " ====");
    }

    /**
     * Log an informational message to both console and Extent report.
     */
    public static void logInfo(String message) {
        if (test != null) {
            test.log(Status.INFO, message);
        }
        System.out.println("[INFO] " + message);
    }

    /**
     * Log a pass message.
     */
    public static void logPass(String message) {
        if (test != null) {
            test.log(Status.PASS, message);
        }
        System.out.println("[PASS] " + message);
    }

    /**
     * Log a fail message.
     */
    public static void logFail(String message) {
        if (test != null) {
            test.log(Status.FAIL, message);
        }
        System.err.println("[FAIL] " + message);
    }

    /**
     * End and flush the current test.
     */
    public static void endTest() {
        if (extent != null) {
            extent.flush();
        }
        System.out.println("==== Test Completed ====");
    }
}